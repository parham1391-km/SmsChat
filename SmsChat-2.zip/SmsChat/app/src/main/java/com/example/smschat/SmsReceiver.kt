package com.example.smschat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.smschat.data.AppDatabase
import com.example.smschat.data.Message
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * وقتی سیستم‌عامل یک پیامک جدید دریافت می‌کند (و این اپ، اپ پیش‌فرض SMS باشد)،
 * این Receiver فراخوانی می‌شود و پیام را در دیتابیس محلی ذخیره می‌کند.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // چند تکه‌ی یک پیامک طولانی را به هم می‌چسبانیم
        val address = messages[0].originatingAddress ?: return
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }
        val timestamp = messages[0].timestampMillis

        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getInstance(context.applicationContext)

            // بررسی این‌که آیا فرستنده، عضو یکی از گروه‌های محلی است یا نه (best-effort)
            val groupId = db.groupDao().findGroupIdForNumber(address)

            db.messageDao().insert(
                Message(
                    address = address,
                    groupId = groupId,
                    body = fullBody,
                    timestamp = timestamp,
                    isSent = false,
                    status = "received"
                )
            )
        }
    }
}
