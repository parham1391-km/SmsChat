package com.example.smschat

import android.content.Context
import android.telephony.SmsManager
import com.example.smschat.data.AppDatabase
import com.example.smschat.data.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * مسئول فرستادن پیامک واقعی از طریق SmsManager
 * و ذخیره‌ی نسخه‌ی محلی آن در دیتابیس تا در چت نمایش داده شود.
 */
object SmsSender {

    suspend fun sendMessage(context: Context, address: String, body: String) {
        sendRawSms(context, address, body)

        // ذخیره در دیتابیس محلی تا در رابط چت دیده شود
        withContext(Dispatchers.IO) {
            val db = AppDatabase.getInstance(context)
            db.messageDao().insert(
                Message(
                    address = address,
                    groupId = null,
                    body = body,
                    timestamp = System.currentTimeMillis(),
                    isSent = true,
                    status = "sent"
                )
            )
        }
    }

    /**
     * ارسال پیام به یک گروه: چون پیامک استاندارد مفهوم «گروه» ندارد،
     * برای هر عضو یک SMS جداگانه فرستاده می‌شود، ولی در دیتابیس محلی
     * فقط یک ردیف با groupId ذخیره می‌شود تا در چت به‌صورت یک پیام دیده شود.
     */
    suspend fun sendGroupMessage(context: Context, groupId: Long, body: String) {
        withContext(Dispatchers.IO) {
            val db = AppDatabase.getInstance(context)
            val members = db.groupDao().getMembers(groupId)
            members.forEach { member ->
                sendRawSms(context, member.phoneNumber, body)
            }
            db.messageDao().insert(
                Message(
                    address = null,
                    groupId = groupId,
                    body = body,
                    timestamp = System.currentTimeMillis(),
                    isSent = true,
                    status = "sent"
                )
            )
        }
    }

    private fun sendRawSms(context: Context, address: String, body: String) {
        val smsManager = context.getSystemService(SmsManager::class.java)
        // پیام‌های طولانی باید به چند تکه تقسیم شوند (محدودیت SMS استاندارد ~160 کاراکتر)
        val parts = smsManager.divideMessage(body)
        smsManager.sendMultipartTextMessage(address, null, parts, null, null)
    }
}
