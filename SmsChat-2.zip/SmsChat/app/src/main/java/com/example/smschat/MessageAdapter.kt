package com.example.smschat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.smschat.data.Message
import com.example.smschat.databinding.ItemMessageReceivedBinding
import com.example.smschat.databinding.ItemMessageSentBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val TYPE_SENT = 1
private const val TYPE_RECEIVED = 2

class MessageAdapter(
    private var items: List<Message>,
    private val isGroup: Boolean = false,
    private val onLongClick: (Message) -> Unit = {}
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun getItemViewType(position: Int) =
        if (items[position].isSent) TYPE_SENT else TYPE_RECEIVED

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_SENT) {
            SentVH(ItemMessageSentBinding.inflate(inflater, parent, false))
        } else {
            ReceivedVH(ItemMessageReceivedBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        when (holder) {
            is SentVH -> {
                holder.binding.textBody.text = item.body
                holder.binding.textTime.text = sdf.format(Date(item.timestamp))
                holder.binding.root.setOnLongClickListener {
                    onLongClick(item)
                    true
                }
            }
            is ReceivedVH -> {
                holder.binding.textBody.text = item.body
                holder.binding.textTime.text = sdf.format(Date(item.timestamp))
                // در چت گروهی، شماره‌ی فرستنده روی هر پیام دریافتی نشان داده می‌شود
                if (isGroup) {
                    holder.binding.textSender.visibility = android.view.View.VISIBLE
                    holder.binding.textSender.text = item.address ?: ""
                } else {
                    holder.binding.textSender.visibility = android.view.View.GONE
                }
                holder.binding.root.setOnLongClickListener {
                    onLongClick(item)
                    true
                }
            }
        }
    }

    override fun getItemCount() = items.size

    fun updateList(newItems: List<Message>) {
        items = newItems
        notifyDataSetChanged()
    }

    class SentVH(val binding: ItemMessageSentBinding) : RecyclerView.ViewHolder(binding.root)
    class ReceivedVH(val binding: ItemMessageReceivedBinding) : RecyclerView.ViewHolder(binding.root)
}
