package com.example.smschat.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * یک ردیف پیامک در دیتابیس محلی.
 * address = شماره طرف مقابل در چت‌های دونفره (چه فرستنده، چه گیرنده)
 * groupId = اگر پیام متعلق به یک گروه باشد پر می‌شود؛ در غیر این صورت null است
 * isSent  = true یعنی توسط خود ما فرستاده شده، false یعنی دریافتی است
 */
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val address: String?,
    val groupId: Long? = null,
    val body: String,
    val timestamp: Long,
    val isSent: Boolean,
    val status: String = "sent" // sent, delivered, failed, received
)
