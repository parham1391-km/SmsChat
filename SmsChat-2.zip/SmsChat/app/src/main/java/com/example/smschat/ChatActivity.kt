package com.example.smschat

import android.app.AlertDialog
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.smschat.data.AppDatabase
import com.example.smschat.data.Message
import com.example.smschat.databinding.ActivityChatBinding
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var adapter: MessageAdapter

    private var address: String? = null
    private var groupId: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        address = intent.getStringExtra("address")
        groupId = if (intent.hasExtra("groupId")) intent.getLongExtra("groupId", -1L) else null

        if (address == null && groupId == null) {
            finish()
            return
        }

        val db = AppDatabase.getInstance(applicationContext)
        adapter = MessageAdapter(
            items = emptyList(),
            isGroup = groupId != null,
            onLongClick = { message -> confirmDeleteMessage(message) }
        )
        binding.recyclerMessages.layoutManager = LinearLayoutManager(this)
        binding.recyclerMessages.adapter = adapter

        if (groupId != null) {
            lifecycleScope.launch {
                val group = db.groupDao().getGroup(groupId!!)
                binding.textChatTitle.text = "👥 " + (group?.name ?: getString(R.string.title_group))
            }
            db.messageDao().getMessagesForGroup(groupId!!).observe(this) { list ->
                adapter.updateList(list)
                if (list.isNotEmpty()) {
                    binding.recyclerMessages.scrollToPosition(list.size - 1)
                }
            }
        } else {
            binding.textChatTitle.text = address
            db.messageDao().getMessagesForAddress(address!!).observe(this) { list ->
                adapter.updateList(list)
                if (list.isNotEmpty()) {
                    binding.recyclerMessages.scrollToPosition(list.size - 1)
                }
            }
        }

        binding.buttonSend.setOnClickListener {
            val text = binding.editMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                lifecycleScope.launch {
                    if (groupId != null) {
                        SmsSender.sendGroupMessage(applicationContext, groupId!!, text)
                    } else {
                        SmsSender.sendMessage(applicationContext, address!!, text)
                    }
                }
                binding.editMessage.text.clear()
            }
        }
    }

    private fun confirmDeleteMessage(message: Message) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_delete_title))
            .setMessage(getString(R.string.confirm_delete_message_message))
            .setPositiveButton(getString(R.string.action_delete)) { _, _ ->
                lifecycleScope.launch {
                    AppDatabase.getInstance(applicationContext).messageDao().deleteMessage(message)
                }
            }
            .setNegativeButton(getString(R.string.action_cancel), null)
            .show()
    }
}
