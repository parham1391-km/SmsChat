package com.example.smschat.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface MessageDao {

    @Insert
    suspend fun insert(message: Message): Long

    // همه پیام‌های یک مکالمه با یک شماره خاص، مرتب‌شده بر اساس زمان
    @Query("SELECT * FROM messages WHERE address = :address ORDER BY timestamp ASC")
    fun getMessagesForAddress(address: String): LiveData<List<Message>>

    // آخرین پیام هر مکالمه دونفره (groupId خالی)، برای نمایش در لیست چت‌ها
    @Query(
        """
        SELECT * FROM messages 
        WHERE groupId IS NULL AND id IN (
            SELECT MAX(id) FROM messages WHERE groupId IS NULL GROUP BY address
        )
        ORDER BY timestamp DESC
        """
    )
    fun getLastMessagePerConversation(): LiveData<List<Message>>

    // تمام پیام‌های یک گروه خاص
    @Query("SELECT * FROM messages WHERE groupId = :groupId ORDER BY timestamp ASC")
    fun getMessagesForGroup(groupId: Long): LiveData<List<Message>>

    // آخرین پیام هر گروه، برای نمایش در لیست چت‌ها
    @Query(
        """
        SELECT * FROM messages 
        WHERE groupId IS NOT NULL AND id IN (
            SELECT MAX(id) FROM messages WHERE groupId IS NOT NULL GROUP BY groupId
        )
        ORDER BY timestamp DESC
        """
    )
    fun getLastMessagePerGroup(): LiveData<List<Message>>

    // حذف یک پیام تکی (فقط از دیتابیس محلی؛ اگر قبلاً ارسال شده، از شبکه اپراتور پاک نمی‌شود)
    @Delete
    suspend fun deleteMessage(message: Message)

    // حذف کل مکالمه با یک شماره
    @Query("DELETE FROM messages WHERE address = :address AND groupId IS NULL")
    suspend fun deleteConversation(address: String)

    // حذف کل پیام‌های یک گروه
    @Query("DELETE FROM messages WHERE groupId = :groupId")
    suspend fun deleteGroupMessages(groupId: Long)
}
