package com.example.smschat.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface GroupDao {

    @Insert
    suspend fun insertGroup(group: ChatGroup): Long

    @Insert
    suspend fun insertMember(member: GroupMember): Long

    @Insert
    suspend fun insertMembers(members: List<GroupMember>)

    @Query("SELECT * FROM groups ORDER BY name ASC")
    fun getAllGroups(): LiveData<List<ChatGroup>>

    @Query("SELECT * FROM groups WHERE id = :groupId")
    suspend fun getGroup(groupId: Long): ChatGroup?

    @Query("SELECT * FROM group_members WHERE groupId = :groupId")
    suspend fun getMembers(groupId: Long): List<GroupMember>

    // برای تشخیص این‌که آیا یک پیامک دریافتی، از عضو یکی از گروه‌هاست یا نه
    // (best-effort: اگر شماره در چند گروه عضو باشد، اولین گروه برگردانده می‌شود)
    @Query("SELECT groupId FROM group_members WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun findGroupIdForNumber(phoneNumber: String): Long?

    @Delete
    suspend fun deleteGroup(group: ChatGroup)

    @Query("DELETE FROM group_members WHERE groupId = :groupId")
    suspend fun deleteMembersForGroup(groupId: Long)
}
