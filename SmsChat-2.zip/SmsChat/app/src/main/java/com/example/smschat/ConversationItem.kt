package com.example.smschat

/**
 * یک ردیف در لیست مکالمات؛ می‌تواند یک چت دونفره یا یک گروه باشد.
 */
data class ConversationItem(
    val title: String,       // شماره تلفن (دونفره) یا نام گروه
    val lastMessage: String,
    val timestamp: Long,
    val isGroup: Boolean,
    val address: String? = null,   // فقط برای چت دونفره
    val groupId: Long? = null      // فقط برای گروه
)
