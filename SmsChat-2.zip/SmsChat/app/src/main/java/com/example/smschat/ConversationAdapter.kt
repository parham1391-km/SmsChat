package com.example.smschat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.smschat.databinding.ItemConversationBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ConversationAdapter(
    private var items: List<ConversationItem>,
    private val onClick: (ConversationItem) -> Unit
) : RecyclerView.Adapter<ConversationAdapter.VH>() {

    inner class VH(val binding: ItemConversationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemConversationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val prefix = if (item.isGroup) "👥 " else ""
        holder.binding.textAddress.text = prefix + item.title
        holder.binding.textLastMessage.text = item.lastMessage
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        holder.binding.textTime.text = sdf.format(Date(item.timestamp))
        holder.binding.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size

    fun itemAt(position: Int) = items[position]

    fun updateList(newItems: List<ConversationItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
