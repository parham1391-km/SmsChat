package com.example.smschat

import android.Manifest
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.smschat.data.AppDatabase
import com.example.smschat.data.ChatGroup
import com.example.smschat.data.Message
import com.example.smschat.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ConversationAdapter

    private val requiredPermissions = arrayOf(
        Manifest.permission.SEND_SMS,
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            checkDefaultSmsApp()
        }
    }

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* نتیجه‌ی انتخاب اپ پیش‌فرض SMS، کاربر خودش تایید می‌کند */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ConversationAdapter(emptyList()) { item ->
            val intent = Intent(this, ChatActivity::class.java)
            if (item.isGroup) {
                intent.putExtra("groupId", item.groupId)
            } else {
                intent.putExtra("address", item.address)
            }
            startActivity(intent)
        }
        binding.recyclerConversations.layoutManager = LinearLayoutManager(this)
        binding.recyclerConversations.adapter = adapter
        attachSwipeToDelete()

        binding.fabNewChat.setOnClickListener {
            val address = binding.editNewNumber.text.toString().trim()
            if (address.isNotEmpty()) {
                val intent = Intent(this, ChatActivity::class.java)
                intent.putExtra("address", address)
                startActivity(intent)
            }
        }

        binding.buttonNewGroup.setOnClickListener {
            startActivity(Intent(this, CreateGroupActivity::class.java))
        }

        observeConversations()
        ensurePermissions()
    }

    private fun observeConversations() {
        val db = AppDatabase.getInstance(applicationContext)
        val convSource = db.messageDao().getLastMessagePerConversation()
        val groupMsgSource = db.messageDao().getLastMessagePerGroup()
        val groupsSource = db.groupDao().getAllGroups()

        var lastConv: List<Message> = emptyList()
        var lastGroupMsg: List<Message> = emptyList()
        var lastGroups: List<ChatGroup> = emptyList()

        val merged = MediatorLiveData<List<ConversationItem>>()

        fun recompute() {
            val groupNameMap = lastGroups.associateBy { it.id }
            val convItems = lastConv.map {
                ConversationItem(
                    title = it.address ?: "",
                    lastMessage = it.body,
                    timestamp = it.timestamp,
                    isGroup = false,
                    address = it.address
                )
            }
            val groupItems = lastGroupMsg.mapNotNull { msg ->
                val groupId = msg.groupId ?: return@mapNotNull null
                val name = groupNameMap[groupId]?.name ?: return@mapNotNull null
                ConversationItem(
                    title = name,
                    lastMessage = msg.body,
                    timestamp = msg.timestamp,
                    isGroup = true,
                    groupId = groupId
                )
            }
            merged.value = (convItems + groupItems).sortedByDescending { it.timestamp }
        }

        merged.addSource(convSource) { lastConv = it; recompute() }
        merged.addSource(groupMsgSource) { lastGroupMsg = it; recompute() }
        merged.addSource(groupsSource) { lastGroups = it; recompute() }

        merged.observe(this) { list -> adapter.updateList(list) }
    }

    private fun attachSwipeToDelete() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: androidx.recyclerview.widget.RecyclerView,
                viewHolder: androidx.recyclerview.widget.RecyclerView.ViewHolder,
                target: androidx.recyclerview.widget.RecyclerView.ViewHolder
            ) = false

            override fun onSwiped(
                viewHolder: androidx.recyclerview.widget.RecyclerView.ViewHolder,
                direction: Int
            ) {
                val position = viewHolder.adapterPosition
                val item = adapter.itemAt(position)
                confirmDeleteConversation(item)
            }
        }
        ItemTouchHelper(callback).attachToRecyclerView(binding.recyclerConversations)
    }

    private fun confirmDeleteConversation(item: ConversationItem) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_delete_title))
            .setMessage(getString(R.string.confirm_delete_conversation_message))
            .setPositiveButton(getString(R.string.action_delete)) { _, _ ->
                lifecycleScope.launch {
                    val db = AppDatabase.getInstance(applicationContext)
                    if (item.isGroup && item.groupId != null) {
                        db.messageDao().deleteGroupMessages(item.groupId)
                    } else if (item.address != null) {
                        db.messageDao().deleteConversation(item.address)
                    }
                }
            }
            .setNegativeButton(getString(R.string.action_cancel)) { dialog, _ ->
                dialog.dismiss()
                adapter.notifyDataSetChanged() // برگرداندن ردیف کشیده‌شده در صورت انصراف
            }
            .setOnCancelListener {
                adapter.notifyDataSetChanged()
            }
            .show()
    }

    private fun ensurePermissions() {
        val notGranted = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            permissionLauncher.launch(notGranted.toTypedArray())
        } else {
            checkDefaultSmsApp()
        }
    }

    /**
     * برای این‌که SmsReceiver واقعاً پیامک‌های ورودی را دریافت کند،
     * این اپ باید اپ پیش‌فرض SMS گوشی باشد. این مرحله را فقط کاربر
     * می‌تواند از طریق این دیالوگ سیستمی تایید کند.
     */
    private fun checkDefaultSmsApp() {
        val myPackage = packageName
        val currentDefault = Telephony.Sms.getDefaultSmsPackage(this)
        if (currentDefault == myPackage) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_SMS)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                roleLauncher.launch(intent)
            }
        } else {
            val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, myPackage)
            roleLauncher.launch(intent)
        }
    }
}
