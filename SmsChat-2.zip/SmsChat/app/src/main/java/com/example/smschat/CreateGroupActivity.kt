package com.example.smschat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.smschat.data.AppDatabase
import com.example.smschat.data.ChatGroup
import com.example.smschat.data.GroupMember
import com.example.smschat.databinding.ActivityCreateGroupBinding
import kotlinx.coroutines.launch

class CreateGroupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateGroupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateGroupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonCreateGroup.setOnClickListener {
            val name = binding.editGroupName.text.toString().trim()
            val numbersRaw = binding.editGroupNumbers.text.toString().trim()

            if (name.isEmpty() || numbersRaw.isEmpty()) return@setOnClickListener

            // شماره‌ها با کاما یا خط جدید از هم جدا می‌شوند
            val numbers = numbersRaw
                .split(",", "\n")
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            if (numbers.isEmpty()) return@setOnClickListener

            lifecycleScope.launch {
                val db = AppDatabase.getInstance(applicationContext)
                val groupId = db.groupDao().insertGroup(ChatGroup(name = name))
                val members = numbers.map { GroupMember(groupId = groupId, phoneNumber = it) }
                db.groupDao().insertMembers(members)
                finish()
            }
        }
    }
}
